package cybersoft.java12.jsp.util;

public class UrlUtils {
	/* CUSTOMER */
	public static final String CUSTOMER_DASHBOARD = "/customer";
	public static final String CUSTOMER_ADD = "/customer/add";
	public static final String CUSTOMER_UPDATE = "/customer/update";
	public static final String CUSTOMER_DELETE = "/customer/delete";
}
