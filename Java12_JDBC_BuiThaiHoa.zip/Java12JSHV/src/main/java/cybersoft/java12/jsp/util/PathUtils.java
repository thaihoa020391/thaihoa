package cybersoft.java12.jsp.util;

public class PathUtils {
	/* CUSTOMER */
	public static final String CUSTOMER_DASHBOARD = "/WEB-INF/views/customer/customer-dashboard.jsp";
	public static final String CUSTOMER_ADD = "/WEB-INF/views/customer/customer-add.jsp";
	public static final String CUSTOMER_UPDATE = "/WEB-INF/views/customer/customer-update.jsp";
}
