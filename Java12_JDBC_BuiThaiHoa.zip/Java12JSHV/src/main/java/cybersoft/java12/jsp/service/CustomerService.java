package cybersoft.java12.jsp.service;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import cybersoft.java12.jsp.model.Customer;
import cybersoft.java12.jsp.repository.CustomerRepository;

public class CustomerService {
	private List<Customer> customers;
	private CustomerRepository repository;
	
	public CustomerService() {
		repository = new CustomerRepository();
		customers = new LinkedList<Customer>();	
	}
	
	/* hiện thực code cho các phương thức sau: */
	
	/* - findAllCustomers: 
	 	* trả về danh sách customer đang quản lý */
	public List<Customer> findAllCustomers(){
		return repository.findAllCustomer();
	}
	
	/* - findCustomerByCode: 
		 * trả về 1 customer có code bằng với tham số được truyền vào */
	public Customer findCustomerByCode(int code) {
		return	repository.findCustomerByCode(code);
	}
	
	/** - deleteCustomerByCode:
	 	* xóa customer có mã code bằng với tham số được truyền vào */
	public int deleteCustomerByCode(int code) {
		return repository.deleteCustomerByCode(code);
	}
	
	/* - addNewCustomer:
	 	* thêm customer vào danh sách quản lý */
	public int addNewCustomer(Customer customer) {
		return	repository.addNewCustomer(customer);
	}

	public void update(Customer customerToUpdate) {	
		int result = repository.updateCustomer(customerToUpdate);
		if(result == 1) {
			System.out.println("updateCustomer complete !!!");
		} else {
			System.out.println("updateCustomer not complete !!!");
		}
	}
	
}
